<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card px-4">
                <div class="card-header my-4"><?php echo e(__('Tablero de Usuarios')); ?></div>
                <form action="<?php echo e(route('user.update',$user->id)); ?>" method="POST" class="row g-3" enctype="multipart/form-data">

                <div class="card-body my-2">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                        </div>
                        
                    <?php endif; ?>
                    <input type="file" name="image" class="d-none" id="input_file">
                    <?php if(Auth::user()->image): ?>
                      <img onclick="open_file()" class="image rounded-circle" src="<?php echo e(asset('/storage/images/'.Auth::user()->image)); ?>" alt="profile_image" style="width: 80px;height: 80px; padding: 10px; margin: 0px; ">
                    <?php else: ?>
                    <img onclick="open_file()" class="image rounded-circle" src="<?php echo e(asset('/storage/images/'.Auth::user()->image)); ?>" alt="profile_image" style="width: 80px;height: 80px; padding: 10px; margin: 0px; ">   
                     <?php endif; ?>
    <div class="col-md-6">
<h5 class="mb-2"><strong><?php echo e($user->name); ?></strong></h5>
<p class="text-muted">Diseñador Wep <span class="badge bg-primary">PRO</span></p>
</div>

<div class="col-md-6">
  <label for="exampleFormControlTextarea2">Hablame un poco de ti</label>
  <textarea name="descripcion"class="form-control rounded-0" id="exampleFormControlTextarea2" rows="3"><?php echo e($user->descripcion); ?></textarea>
</div>

                   
                
                  <?php echo method_field('PUT'); ?>
                  <?php echo csrf_field(); ?>
                    <div class="col-md-6">
                      <label for="inputnamel4" class="form-label">Nombre</label>
                      <input type="text" name="name" class="form-control" id="inputname" value="<?php echo e($user->name); ?>">

                    </div>
                    <div class="col-md-6">
                      <label for="inputEmail4" class="form-label">Correo electronico</label>
                      <input type="email" name="email" class="form-control" id="inputEmail4" value="<?php echo e($user->email); ?>">
                    </div>
                    <div class="col-12">
                      <label for="inputAddress" class="form-label">Direccion</label>
                      <input type="text" name="address" class="form-control" id="inputAddress" value="<?php echo e($user->address); ?>" placeholder="Caracas,Av sucre">
                    </div>
                    <div class="col-12">
                      <label for="inputAddress2" class="form-label">Cual es tu especialidad</label>
                      <input type="text" name="specialty" class="form-control" id="inputAddress2" value="<?php echo e($user->specialty); ?>" placeholder="HTML,CSS,JAVA,PHP...etc">
                    </div>
                    <div class="col-md-6">
                      <label for="inputCity" class="form-label">Programas que manejas</label>
                      <input type="text" name="programs" class="form-control" id="inputCity" value="<?php echo e($user->programs); ?>">
                    </div>
                    <div class="col-md-4">
                      <label for="inputState" class="form-label">Nivel de experiencia</label>
                      <select id="inputState" name="experience" class="form-select" value="<?php echo e($user->experience); ?>">
                        <option selected>Junior</option>
                        <option>Semi senior</option>
                        <option>Senior</option>
                      </select>
                    </div>
                    <div class="col-md-2">
                      <label for="inputZip" class="form-label">F.E.N</label>
                      <input type="date" name="date" class="form-control" id="inputZip" value="<?php echo e($user->date); ?>">
                    </div>
                   
                    <div class="col-12 my-4">
                      <button type="submit" class="btn btn-primary">Actualizar</button>
                    </div>
                  </form>
            </div>
        </div>   
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alumnos_perfiles\resources\views/home.blade.php ENDPATH**/ ?>